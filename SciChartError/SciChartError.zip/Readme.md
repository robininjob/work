# SciChart.js Tutorial 2 - Adding Series and Data

To view the full text of this tutorial online, visit www.scichart.com/javascript-chart-documentation 

To run the tutorial, open this folder in VSCode, and run the following commands:

* `npm install`
* `npm start`

Then visit https://localhost:8080 in your web browser! 
